# Operations Guide

How staff use the Hotel Centrum management app day to day. Pair this
with the 30-minute training session for each role.

---

## Logging in

1. Open the app URL (given by the admin)
2. Enter your email and password
3. Tap **Hyr** (Sign In)

If you forget your password, ask the admin to reset it in Supabase.
(No self-service password reset yet — v2 feature.)

---

## Role guide

### Admin
- Full access to everything
- Can change staff roles, activate/deactivate users
- Only person who creates new staff users

### Manager
- Full access to all day-to-day operations
- Can view staff but not edit them
- Primary user of the Reports page

### Reception
- Full access: Dashboard, Bookings, Calendar, Housekeeping, Minibar
- No access to Reports or Staff management
- Creates reservations, checks guests in/out, manages minibar charges

### Cleaner
- Limited access: Dashboard + Housekeeping only
- Optimized for mobile (big buttons, simple workflow)
- Cannot see guest names, payment info, or financial data

---

## Daily flow by role

### Reception (morning shift)

1. **Open Bookings → tab "↓ Ardhjet sot"** (Arrivals today) —
   see who's arriving
2. **Open Dashboard** — verify their rooms are clean (green badge)
3. **When guests arrive:**
   - Go to Bookings → find them → tap their row
   - Tap **✓ Regjistro hyrjen** (Check In) to check them in
   - The room automatically flips to "Occupied"
4. **Throughout the day:**
   - Mark charges on the Minibar page as guests consume items
   - Update room statuses if needed

### Reception (evening / check-out shift)

1. **Open Bookings → tab "↑ Nisjet sot"** (Departures today)
2. **For each departing guest:**
   - Go to Minibar → their room → tap **Ngarko** to finalize minibar charges
   - Back to Bookings → their booking → **€ Shëno si të paguar** (Mark Paid)
     after they settle the bill
   - Then **→ Regjistro daljen** (Check Out)
   - The room automatically flips to "Dirty" so housekeeping knows to clean it

### Cleaner

1. **Open Housekeeping** — sees "Needs Attention" by default (dirty rooms only)
2. **For each room:**
   - Tap the room tile
   - Bottom bar slides up with room info
   - Tap **▶ Fillo** (Start) when you begin cleaning
   - Tap **✓ E pastruar** (Cleaned) when you finish
3. That's it. The room is removed from "Needs Attention" and visible
   in "Cleaned" tab for the supervisor to inspect.

### Manager (morning check)

1. **Open Reports** — see today's arrivals + departures counts
2. **Open Dashboard** — spot-check: how many rooms occupied? Any maintenance issues?
3. **Open Housekeeping → tab "Cleaned"** — inspect rooms marked clean
   - Tap **✓ Inspekto** to approve
   - Or **← Ripastro** if not up to standard

### Manager (end of day)

1. **Open Reports**
2. **Minibar tab** — see today's total revenue
3. **Cleaners tab** — see what each cleaner did
4. **Dirty Rooms tab** — make sure nothing's left for tomorrow

---

## Common tasks

### Create a new reservation
Bookings → **+ Rezervim i ri** → fill in guest name, dates, room → Create.
If the room is already booked for those dates, the system will tell you
and block the reservation.

### Add a past booking (walk-in that forgot to register)
Same as above, but pick a past date. You'll get a confirmation warning
("Check-in date is in the past, continue?"). Confirm to create it.

### Cancel a booking
Open the booking → **✕ Anulo rezervimin** → confirm.
The room doesn't automatically free up (in case the guest is still there) —
update room status manually on Dashboard if needed.

### Mark a room as under maintenance
Dashboard → tap the room → tap **maintenance** button.
It's removed from availability for new bookings until you change it back.

### Record a minibar consumption
Minibar → tap the room in the left list → tap **+** next to the product.
Do this every time a guest consumes something.
When they're ready to check out, tap **Ngarko €X** to add it all to their bill.

### Re-clean a room that wasn't done properly
Housekeeping → find the room → tap it → bottom bar →
tap **← Ripastro** (Redo). The cleaner gets notified via the updated status.

---

## What happens when staff make mistakes

### "I checked someone in by accident"
The booking detail panel lets admins reverse this, but reception can't.
Ask a manager or admin to fix it. They can set status back to confirmed.

### "I charged the wrong minibar item"
Right now, there's no undo. Tap the item's **−** button to reduce the
quantity before charging. Once charged, it's on the bill. If a mistake
happens, manager can adjust the booking's `total_amount` directly in
Supabase or with an admin-level fix.

### "I deleted something I shouldn't have"
Nothing in this app actually deletes. All "cancellations" and
"deactivations" flip a status flag. The underlying data stays in the
database forever. If you need to restore: ask admin.

---

## What to do if the app breaks

1. **Take a screenshot** of the error or blank page
2. **Refresh the browser** (Ctrl+F5 on Windows, Cmd+Shift+R on Mac)
3. **Log out and log back in**
4. **If still broken:** use paper/phone to record info manually (guest
   names, rooms, times), and tell admin to check later

The app is new. Expect small bugs in the first few weeks. Don't panic,
don't lose data, report what you saw.

---

## Security reminders

- **Never share your password.** Each person has their own login.
- **Log out on shared computers.** Top right (mobile) or sidebar bottom (desktop).
- **Don't take screenshots of guest data** and share them externally.
- **If you think someone else is using your account, tell admin immediately.**
  They can reset your password.

---

## Cheat sheet (print this)

```
┌──────────────────────────────────────────────┐
│         HOTEL CENTRUM QUICK REFERENCE        │
├──────────────────────────────────────────────┤
│                                              │
│  Check a guest in:                           │
│    Bookings → tap booking → Regjistro hyrjen │
│                                              │
│  Check a guest out:                          │
│    Bookings → tap booking → Regjistro daljen │
│                                              │
│  Mark a room clean (cleaner):                │
│    Housekeeping → tap room → ✓ E pastruar    │
│                                              │
│  Charge the minibar:                         │
│    Minibar → pick room → + for each item     │
│    → Ngarko €X at the end                    │
│                                              │
│  See today's arrivals:                       │
│    Bookings → Ardhjet sot tab                │
│                                              │
│  Check occupancy live:                       │
│    Dashboard → blue rooms are occupied       │
│                                              │
│  Mark as paid:                               │
│    Bookings → tap booking → Shëno si të      │
│    paguar                                    │
│                                              │
└──────────────────────────────────────────────┘
```
