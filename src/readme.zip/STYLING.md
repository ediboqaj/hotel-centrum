# Styling Guide

How styling works in the Hotel Centrum app and how to change it safely.

---

## The single source of truth: CSS variables

All colors, spacing, and visual tokens are defined as CSS variables in
`src/index.css` inside the `:root` block. **Change them there, the whole
app updates.**

```css
:root {
  --sidebar: #0f172a;                       /* Dark navy sidebar */
  --sidebar-hover: rgba(255,255,255,0.07);  /* Nav item hover */
  --sidebar-active: rgba(16,185,129,0.18);  /* Active nav item */
  --accent: #10b981;                        /* Primary buttons/highlights */
  --accent-dark: #059669;                   /* Button hover */
  --surface: #ffffff;                       /* Card/panel backgrounds */
  --bg: #f1f5f9;                            /* Page background */
  --border: #e2e8f0;                        /* Borders, dividers */
  --text: #1e293b;                          /* Primary text */
  --muted: #64748b;                         /* Secondary text, labels */
  --danger: #ef4444;                        /* Destructive actions */
  --success: #22c55e;                       /* Positive states */
  --warning: #f59e0b;                       /* Cautionary states */
}
```

Anywhere in the app, use these like `background: var(--accent)` or
`color: var(--muted)`.

---

## Where to change what

### Brand colors
Edit `--accent`, `--accent-dark`, `--sidebar` in `src/index.css`.
Also search for hardcoded values (a few slipped through):
- `#6ee7b7` in Sidebar.jsx and BottomNav.jsx (mint green active nav text)
- `#10b981` in a handful of inline styles

### Status badge colors
Edit `STATUS_STYLES` in `src/components/Badge.jsx`. Each status has its
own background + text color pair.

### Typography
Change the font family in `src/index.css` `body { font-family: ... }`.
Currently uses system fonts — fast, legible, matches OS styling.

### Spacing / padding
Inline styles are used throughout (`padding: 14`, `gap: 8`, etc.). There's
no spacing scale token system — if you want one, add it to `:root`
(e.g. `--spacing-2: 8px`, `--spacing-3: 12px`) and refactor over time.

### Border radius
Search for `borderRadius` — mostly uses 7, 8, 10, or 12. To unify, create
tokens like `--radius-md: 8px` in `:root`.

---

## Component style conventions

- **All styles are inline** using the `style={{ ... }}` prop. We chose
  this to keep components self-contained (no external CSS files to hunt
  through). Downside: harder to override globally.
- **No CSS-in-JS libraries** (styled-components, emotion). Just plain
  React `style` prop.
- **No Tailwind.** We use CSS variables + inline styles, not utility classes.

---

## Responsive breakpoints

There's one breakpoint: **900px**. Below it, the mobile layout kicks in
(sidebar hides, bottom nav appears, modals become bottom sheets, tables
become cards).

Defined in `src/hooks/useMobile.js`:
```js
const BREAKPOINT = 900
```

To change it, edit this value. All components that use `useMobile()` will
pick it up.

---

## Dark mode?

Not implemented. Would require:
1. Adding a `data-theme` attribute on `<html>`
2. Duplicating CSS variables under `[data-theme="dark"]`
3. A toggle UI (probably in the user menu)

Rough effort: 1 day. Worth doing only if staff actually ask for it.

---

## Accessibility notes

- **Color contrast:** verified for the default palette (navy sidebar,
  green accent, slate text). If you change colors, run through
  [WebAIM contrast checker](https://webaim.org/resources/contrastchecker/).
- **Minimum touch target:** 44×44px on mobile (Apple HIG standard).
  Nav buttons, quantity buttons, etc. all meet this.
- **Keyboard navigation:** works on all forms and buttons. We didn't
  add focus rings on every element — if you want better keyboard UX,
  add `outline: 2px solid var(--accent)` on `:focus-visible` states.

---

## Logo guidelines

- **Favicon:** `public/logoC.png`. Should look clear at 32×32 and 16×16.
  Avoid fine detail.
- **Sidebar logo:** `public/logoC.png` at ~32px height. If logo is dark
  it won't be visible on the navy sidebar — use a white/light version
  for that spot.
- **Login logo:** same file but ~48px height. Sits on light background,
  so dark logos work here.

If you want two different logo variants (dark for login, light for
sidebar), store both in `public/` and reference them separately:
- `public/logo-dark.png` → used in `src/pages/Login.jsx`
- `public/logo-light.png` → used in `src/components/Sidebar.jsx`

---

## Future: extracting a design system

If the app grows, consider:

1. **Move inline styles to CSS classes** — one stylesheet per component.
   Harder to refactor, easier to theme long-term.
2. **Add a component library** — wrap Button, Input, Card, Modal as
   proper reusable components with consistent props.
3. **Add Tailwind** — fastest way to get a proper utility-class system.
4. **Build a Storybook** — catalog every component visually. Great for
   handing off to designers or new developers.

For a 55-room hotel with one developer, the current inline-style
approach is fine. Re-evaluate if the app grows past ~20 pages.
